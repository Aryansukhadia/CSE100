import subprocess
import tkinter as tk
import csv
from tkinter import *
from PIL import ImageTk, Image
# Create a window
root = tk.Tk()
w, h = root.winfo_screenwidth(), root.winfo_screenheight()
root.geometry("%dx%d+0+0" % (w, h))
root.title("Login and Sign-up")

# Create a label for the login page
login_label = tk.Label(root, text="Login")
login_label.pack()

image_file = "C:/Users/hp/Downloads/CSE100 PROJECT/CSE100 project file/bg2.png"
image = Image.open(image_file)
background_image = ImageTk.PhotoImage(image)

# create a label with the background image
background_label = Label(root, image=background_image)
background_label.place(relwidth=1, relheight=1)

# Create a frame to hold the login form
login_frame = tk.Frame(root)
login_frame.pack()

# Create labels and entry fields for the username and password
label1 = Label(root, text="Login",
			font="times 20 bold")
label1.place(x=770, y=80)

username_label=Label(root,text="Username",
			font="times 18")
username_label.place(x=600,y=140)
username_entry=Entry(root,font="times 19")
username_entry.place(x=720,y=140)

password_label=Label(root,text="Password",
			font="times 18")
password_label.place(x=600,y=175)
password_entry=Entry(root,font="times 19",show="*")
password_entry.place(x=720,y=175)

# Create a function to handle the login button click
def handle_login():
    with open('users.csv', 'r') as file:
        reader = csv.reader(file)
        for row in reader:
            if row[0] == username_entry.get() and row[1] == password_entry.get():
                print("Login successful!")
                subprocess.Popen(["python", "C:\\Users\\hp\\Downloads\\CSE100 PROJECT\\CSE100 project file\\main.py"])
                break
        else:
            print("Invalid username or password")

# Create a login button
login_button = Button(root, text="Login", command=handle_login)
# login_button.pack()
login_button.place(x=800, y=215)


# Create a frame to hold the sign-up form
signup_frame = tk.Frame(root)
signup_frame.pack()

# Create labels and entry fields for the username and password

label1 = Label(root, text="Signup",
			font="times 20 bold")
label1.place(x=770, y=270)
new_username_label=Label(root,text="Username",
			font="times 18")
new_username_label.place(x=600,y=330)
new_username_entry=Entry(root,font="times 19")
new_username_entry.place(x=720,y=330)

new_password_label=Label(root,text="Password",
			font="times 18")
new_password_label.place(x=600,y=365)
new_password_entry=Entry(root,font="times 19",show="*")
new_password_entry.place(x=720,y=365)
# Create a function to handle the sign-up button click
def handle_signup():
    with open('users.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([new_username_entry.get(), new_password_entry.get()])
        print("Sign-up successful!")

# Create a sign-up button
Signup_button = Button(root, text="Signup",command=handle_signup)
# login_button.pack()
Signup_button.place(x=800, y=410)
# Start the window
root.mainloop()
