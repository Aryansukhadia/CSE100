username_label = tk.Label(login_frame, text="Username:",font ="times")
username_label.grid(row=0, column=0)
username_entry = tk.Entry(login_frame)
username_entry.grid(row=0, column=1)