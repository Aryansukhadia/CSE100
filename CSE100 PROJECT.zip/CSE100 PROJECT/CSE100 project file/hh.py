import tkinter as tk
from tkinter import filedialog

class RestaurantBillGUI:
    def __init__(self, master):
        self.master = master
        self.master.title("Restaurant Bill")
        
        # Create GUI elements
        self.total_label = tk.Label(self.master, text="Total: ")
        self.total_label.grid(row=0, column=0)
        self.total_entry = tk.Entry(self.master)
        self.total_entry.grid(row=0, column=1)
        
        self.print_button = tk.Button(self.master, text="Print", command=self.save_bill)
        self.print_button.grid(row=1, column=0, columnspan=2, pady=10)
    
    def save_bill(self):
        bill_text = self.total_entry.get()
        
        # Save the bill to internal storage
        file_path = filedialog.asksaveasfilename(defaultextension='.txt')
        with open("Bill Records\\{folder}\\{customer_name+customer_contact+customer_upiid}.txt", 'w') as f:
            f.write(bill_text)
        
        # Show success message
        tk.messagebox.showinfo("Success", "The bill has been saved.")
        
root = tk.Tk()
app = RestaurantBillGUI(root)
root.mainloop()
